export default [
    {
        id: 1,
        count: 0,
        isClick: false
    },
    {
        id: 2,
        count: 1,
        isClick: false
    },
    {
        id: 3,
        count: 5,
        isClick: false
    },
    {
        id: 4,
        count: 2,
        isClick: false
    },
    {
        id: 5,
        count: 0,
        isClick: false
    },
    {
        id: 6,
        count: 0,
        isClick: false
    },
    {
        id: 7,
        count: 0,
        isClick: false
    },
    {
        id: 8,
        count: 0,
        isClick: false
    },
    {
        id: 9,
        count: 0,
        isClick: false
    },
    {
        id: 10,
        count: 0,
        isClick: false
    },
]