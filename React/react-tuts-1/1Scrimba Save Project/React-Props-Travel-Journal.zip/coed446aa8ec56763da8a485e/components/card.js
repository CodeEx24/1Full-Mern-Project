import React from 'react'

export default function Card(props){
    return(
        <section className="main">
            <div className="container">
                <img className="main--left-col" src={props.imageUrl} />
                <div className="main--right-col" >
                    <div className="main--location">
                        <img src="../images/location.png"/>
                        <p>{props.location}</p>
                        <span>View on Google Maps</span>
                    </div>
                    <h1>{props.title}</h1>
                    <h4>{props.startDate} - {props.endDate}</h4>
                    <p>{props.description}</p>
                </div>
            </div>
        </section>
    )
}