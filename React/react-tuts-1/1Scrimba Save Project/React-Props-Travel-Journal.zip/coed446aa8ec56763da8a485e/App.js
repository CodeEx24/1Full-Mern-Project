import React from 'react'
import Navbar from './components/Navbar'
import Card from './components/card'
import data from './data'

export default function App(){
    console.log(data.title)
    const dataElements = data.map(data => {
        return (
            <Card
                id = {data.id}
                {...data}
            />
        )
    })
    
    return(
        <div>
            <Navbar/>
            {dataElements}
        </div>
    )
}