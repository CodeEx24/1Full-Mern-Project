import React from 'react'
import ReactDOM from 'react-dom/client'

function Image(){
    return(
        <img src="https://images.pexels.com/photos/2364580/pexels-photo-2364580.jpeg?cs=srgb&dl=pexels-ficky-2364580.jpg&fm=jpg"/>
    )
}

function Header(){
    return(
        <section className="header">
            <div className="container">
                <h1 className="name">Laura Smith</h1>
                <h3 className="position">Frontend Developer</h3>
                <p className="web-link">laurasmith.website</p>
                <button className="email" type="button">Email</button>
                <button className="linked-in" type="button">Linked In</button>
            </div>
        </section>
    )
}

function Description(){
    return(
        <section className="description">
            <div className="container">
                <h2 className="description--heading">About</h2>
                <p>I am a frontend developer with a particular interest in making things simple and automating daily tasks. I try to keep up with security and best practices, and am always looking for new things to learn.</p>
                <h2 className="description--heading">Interests</h2>
                <p>Food expert. Music scholar. Reader. Internet fanatic. Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.</p>
            </div>
        </section>
    )
}

function SocialMedia(){
    return(
        <footer>
            <img src="https://cdns.iconmonstr.com/wp-content/releases/preview/2017/240/iconmonstr-facebook-6.png"/>
            <img src="https://cdns.iconmonstr.com/wp-content/releases/preview/2017/240/iconmonstr-facebook-6.png"/>
            <img src="https://cdns.iconmonstr.com/wp-content/releases/preview/2017/240/iconmonstr-facebook-6.png"/>
            <img src="https://cdns.iconmonstr.com/wp-content/releases/preview/2017/240/iconmonstr-facebook-6.png"/>
        </footer>
    )
}

function App(){
    return (
        <div className="app">
            <Image />
            <Header />
            <Description />
            <SocialMedia />
        </div>
    )
}

const root = ReactDOM.createRoot(document.getElementById("root"))
root.render(<App />)
