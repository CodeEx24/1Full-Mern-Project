import React from 'react'
import Start from './components/Start'

export default function App(){
    const [start, setStart] = React.useState(false)
    const [quizData, setQuizData] = React.useState([])
    
    function startQuiz(){
        fetch("https://opentdb.com/api.php?amount=5")
            .then((response) => response.json())
            .then((data) => setQuizData(data.results))
    }
    
    const quizElement = quizData.map(quiz => {
        console.log(quiz.question)
        return (
            <div>
                <h3>quiz</h3>
                <div>
                    <button>Dummy Button</button>
                </div>
            </div>
        )
    })
    //arr.splice(2, 0, "Lene"); index, remove item, Item to be pass
    
    // React.useEffect(() => {
    //     console.log(quizData)
    // }, [quizData])
    
    return(
        <div className="main-app">
            {!start && <Start startQuiz={startQuiz}/>}
            {quizElement}
        </div>
    )
}