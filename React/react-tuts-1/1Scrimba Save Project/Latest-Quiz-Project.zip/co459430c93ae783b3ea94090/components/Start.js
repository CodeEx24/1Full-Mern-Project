import React from 'react'

export default function Start(props){
    return (
        <div className="start">
            <img className="start--img-top" src="../images/blobs.png"/>
            <h1 className="start--h1">Quizzical</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vehicula sem id odio maximus, sit amet dignissim erat feugiat. </p>
            <button className="start--btn" onClick={props.startQuiz}>Start Quiz</button>
            <img className="start--img-bot" src="../images/blobs1.png"/>
        </div>
    )
}