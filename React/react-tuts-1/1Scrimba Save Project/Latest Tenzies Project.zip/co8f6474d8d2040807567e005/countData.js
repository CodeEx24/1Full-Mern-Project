export default [
    {
        id: 1,
        count: 1,
        isClick: false
    },
    {
        id: 2,
        count: 2,
        isClick: false
    },
    {
        id: 3,
        count: 3,
        isClick: false
    },
    {
        id: 4,
        count: 4,
        isClick: false
    },
    {
        id: 5,
        count: 5,
        isClick: false
    },
    {
        id: 6,
        count: 1,
        isClick: false
    },
    {
        id: 7,
        count: 2,
        isClick: false
    },
    {
        id: 8,
        count: 3,
        isClick: false
    },
    {
        id: 9,
        count: 4,
        isClick: false
    },
    {
        id: 10,
        count: 5,
        isClick: false
    },
]